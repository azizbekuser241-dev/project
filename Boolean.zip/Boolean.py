# son=int(input('biror son kiriting: '))
# if son > 0:
#     print(True)
# else:
#     print(False)

# 2

# son=int(input('son kiriting: '))
# if son % 2 != 0:
#     print(True)
# else:
#     print(False)


# 3

# A = int(input('A= '))
# if A % 2 == 0:
#     print(True)
# else:
#     print(False)


# 4

# A = int(input('A= '))
# B = int(input('B= '))
# if A > 2 and B <= 3:
#     print(True)
# else:
#     print(False)



# 5


# A = int(input('a= '))
# B = int(input('b= '))
# if A >= 0 or B < -2:
#     print(True)
# else:
#     print(False)



# 6-7

# A = int(input('A='))
# B = int(input('B='))
# C = int(input("C= "))

# if A<=B<=C:
#     print(True)
# else:
#     print(False)



# 8

# A = int(input('A='))
# B = int(input('B='))

# if A and B % 2 != 0:
#     print(True)
# else:
#     print(False)


# 9

# A = int(input('son kiriting: '))
# B = int(input('Yana bir son kiriting: '))
# if A % 2 == 0 and B % 2 != 0 or B % 2 == 0 and A % 2 != 0:
#     print(True)
# else:
#     print(False)


# 10

# A = int(input('son kiriting: '))
# B = int(input('Yana bir son kiriting: '))
# if A % 2 == 0 and B % 2 != 0 :
#     print(f'{B} soni toq va bu {True}')
# elif A % 2 != 0 and B % 2 == 0:
#     print(f'{A} soni toq va bu {True}')
# else:
#     print(False)


# 11

# A = int(input('son kiriting: '))
# B = int(input('Yana bir son kiriting: '))
# if A % 2 == 0 and B % 2 == 0 :
#     print(f'{A,B} sonlari juft va bu {True}')
# elif A % 2 != 0 and B % 2 != 0:
#     print(f'{A,B} sonlari toq va bu {True}')
# else:
#     print(False)


# 12

# A = int(input('son kiriting: '))
# B = int(input('Yana bir son kiriting: '))
# C = int(input('Yana son kiriting: '))
# if A >= 0 and B  >= 0 and C >= 0:
#     print(f'{A,B,C} sonlari musbat va bu {True}')
# else:
#     print(False)
  

# 13 - 14

# A = int(input('son kiriting: '))
# B = int(input('Yana bir son kiriting: '))
# C = int(input('3-sonni kiriting: '))
# if A >= 0 and B and C <= 0 :
#     print(f'{A} soni musbat va bu {True}')
# elif B >= 0 and C and A <= 0:
#     print(f'{B} sonlari musbat va bu {True}')
# elif C >= 0 and A and B <= 0:
#     print(f'{C} soni musbat va bu {True}')
# else:
#     print(False)
  


# 15

# A = int(input('son kiriting: '))
# B = int(input('Yana bir son kiriting: '))
# C = int(input('3-sonni kiriting: '))
# if A and B >= 0 and  C <= 0 :
#     print(f'{A,B} sonlari musbat va bu {True}')
# elif B and C >= 0 and  A <= 0:
#     print(f'{B,C} sonlari musbat va bu {True}')
# elif A and  C >= 0 and  B <= 0:
#     print(f'{A,C} soni musbat va bu {True}')
# else:
#     print(False)


# 16

# S = int(input('Musbat son kiritning: '))
# if 99 >= S >=10 and S % 2 == 0:
#     print(True)
# else:
#     print(False)


# 17
 
S = int(input('Musbat son kiriting: '))
if 999 >= S >= 100 and S % 2 != 0:
    print(True)
else:
    print(False)
    


































































# 21

# son = int(input('3xonali son kiriting: '))
# A= son//100
# B= (son//10)%10
# C= son%10
# if 100<= son <=999 and A<B<C:
#     print(True)
# else:
#     print(False)




